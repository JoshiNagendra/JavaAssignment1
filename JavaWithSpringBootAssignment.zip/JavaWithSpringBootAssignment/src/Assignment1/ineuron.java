package Assignment1;


public class ineuron {

	public static void main(String[] args) {
		
		int n=7;
		for(int i=0;i<n;i++) {
			//Alpha_I
			for(int j=0;j<n;j++) {
				if(i==0||i==(n-1)||j==(n-1)/2) {
					System.out.print("*");
				}else {
					System.out.print(" ");
				}	
				}
			System.out.print("   ");
			//Alpha_N
			for(int j=0;j<n;j++) {
				if(j==0||j==(n-1)||i==j) {
					System.out.print("*");
				}else {
					System.out.print(" ");
				}
			}
			System.out.print("  ");
			//Alpha_E
			for(int j=0;j<n;j++) {
				if(i==0||i==(n-1)||j==0||i==(n-1)/2) {
					System.out.print("*");
				}else {
					System.out.print(" ");
				}
			}
			System.out.print("  ");
			//Alpha_U
			for(int j=0;j<n;j++) {
				if(j==0&&i!=(n-1)||j==(n-1)&&i!=(n-1)||i==(n-1)&&j!=0&&j!=(n-1)) {
					System.out.print("*");
				}else {
					System.out.print(" ");
				}
			}
			System.out.print("  ");
			//Alpha_R
			for(int j=0;j<n;j++) {
				 if(i==0&&j<(n-2)||j==(((n-1)/2)+2)&&i>0&&i<(n-4)||i-j==(((n-1))/2)-1||j==0||i==((n-1)/2)&&j<(n-2)) {
					 System.out.print("*");
				 }else {
					 System.out.print(" ");
				 }
			}
			System.out.print("  ");
			//Alpha_O
			for(int j=0;j<n;j++) {
				if(i==0&&j!=0&&j!=(n-1)||i==(n-1)&&j!=0&&j!=(n-1)||j==0&&i!=0&&i!=(n-1)||j==(n-1)&&i!=0&&i!=(n-1)) {
					System.out.print("*");
				}else {
					System.out.print(" ");
				}
			}
			System.out.print("  ");
			//Alpha_N
			for(int j=0;j<n;j++) {
				if(j==0||j==(n-1)||i==j) {
					System.out.print("*");
				}else {
					System.out.print(" ");
				}
			}
			System.out.println();
		}
	}

}
